branch = 'master'
nightly = False
official = True
version = '8.2.0.24012702'
version_name = '64bit Sensation'
